# Algoritmos y Estructuras de Datos I - FCEQyN - UNaM

## Repositorio general de código usado en clases

Este repositorio contiene los archivos de código fuente javascript que se usan en las clases de la asignatura.

Leer los archivos **README.md** de cada carpeta con la correspondiente descripción de su contenido según se han utilizado en cada clase a la que se hace referencia.
