/**
 * Ejercicio #1 de la clase
 * Consigna: hacer un conversor de AR$ a U$S
 */

let pesos = 14000;

const cotizacionDolarOficial = 70.0;
const cotizacionDolarBlue = 120.0;

let val = pesos / cotizacionDolarOficial;
console.log('La cantidad de dólares que se pueden comprar son: ' + val);

