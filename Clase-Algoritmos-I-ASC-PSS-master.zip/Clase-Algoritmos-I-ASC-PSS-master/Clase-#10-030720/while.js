/**
 * Ejemplo de uso de la estructura While
 */

let temperaturaActual = 15;
const temperaturaDeseada = 28;

while (temperaturaActual < temperaturaDeseada) {
    console.log('Se debe subir la temperatura');
    temperaturaActual++;
}

console.log('Se alcanzó la temperatura deseada');
