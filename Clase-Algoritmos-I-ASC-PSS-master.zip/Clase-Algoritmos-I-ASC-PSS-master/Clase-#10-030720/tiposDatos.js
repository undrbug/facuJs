let unNumero = 10;
let sinValor;
const valorNulo = null;

console.log(typeof unNumero);
console.log(typeof sinValor);
console.log(typeof valorNulo);
