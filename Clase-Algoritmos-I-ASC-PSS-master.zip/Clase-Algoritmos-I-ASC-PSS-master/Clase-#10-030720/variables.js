let variable = 10;
const constante = 20;

console.log(`Valor de la variable al inicio: ${variable}`);
console.log(`Valor de la constante al inicio: ${constante}`);

variable = variable * 2;

console.log(`Valor de la variable modificado: ${variable}`);

//constante = 2;

//console.log(`Valor de la constante modificado: ${constante}`);

