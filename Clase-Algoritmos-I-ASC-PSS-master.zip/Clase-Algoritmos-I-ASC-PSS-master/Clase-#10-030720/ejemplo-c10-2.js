/**
 * Ejercicio #2 de la clase
 * Consigna: imprimir la tabla del 2 usando un bucle For
 */

var tabla = 0;
for (let contador = 1; contador <= 10; contador++) {
    tabla = contador * 2;
    console.log('2x' + contador + 'es igual a ' + tabla);

}
