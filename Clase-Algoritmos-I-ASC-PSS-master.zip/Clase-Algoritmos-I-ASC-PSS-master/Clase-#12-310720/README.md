# Algoritmos y Estructuras de Datos I - FCEQyN - UNaM

## Unidad III

### Clase 12 - 31/07/2020

Repaso de la introducción a JS. Se presentan ejemplos en los siguientes archivos:

* _repaso.js_: Ejemplos presentes en la presentación de la clase a modo de repaso.
* _ejercicio-1-TPB.js_: Ejercicio desarrollado en clase - Ejercicio 1 TP B.
* _ejercicio-3-TPB.js_: Ejercicio desarrollado en clase - Ejercicio 3 TP B.
* _ejercicio-8-TPB.js_: Ejercicio desarrollado en clase - Ejercicio 8 TP B.
