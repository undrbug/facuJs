# Algoritmos y Estructuras de Datos I - FCEQyN - UNaM

## Unidad IV

### Clase 13 - 07/08/2020

Introducción al manejo de cadenas de caracteres (string) con JS. Se presentan ejemplos en los siguientes archivos:

* _fragmentos.js_: Ejemplos presentes en la presentación de la clase.
* _Ejemplo-1.js_: Ejemplo básico desarrollado en clase - .
* _Ejemplo-2.js_: Ejemplo básico desarrollado en clase - Recorrido con procesamiento básico y uso de la propiedad length.
