# Algoritmos y Estructuras de Datos I - FCEQyN - UNaM

## Unidad III

### Clase 11 - 10/07/2020

Continuamos con la introducción a JS. Se presentan ejemplos en los siguientes archivos:

* _funcionSuma.js_: Ejemplo de uso de funciones y lo que pasa una vez que se ejecuta la instrucción return.
* _dosFunciones.js_: Ejemplo de uso de dos funciones con parámetros de igual nombre.
* _ambito-1.js_: Ejemplo básico de ámbito de variables para diferenciar scope de var y let.
* _ambito-2.js_: Ejemplo de ámbito de variables un poco más complejo haciendo un mix de funciones y estructuras de control
